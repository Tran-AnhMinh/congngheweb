/* BÀI B — VIẾT CODE: Phiếu xác nhận đơn in
   Hoàn thiện 4 hàm bên dưới theo mô tả trong de-bai.md (mục 4).
   Không đổi tên hàm, không đổi tham số, không sửa phần "DỮ LIỆU ĐÃ CHO". */

// ---------- DỮ LIỆU ĐÃ CHO (không sửa) ----------
const TEN_XUONG = "Blakletterpress";
const VAT_PHAN_TRAM = 10;

// Đơn gốc: các số lấy từ form nên đang là CHUỖI.
const donGoc = {
	ma: "BL-001",
	khach: { ten: "Nguyễn An", sdt: "0901234567" },
	soLuong: "250",
	donGia: "1500",
	phiGiao: "30000",
	soLanIn: 0
};

// ---------- PHẦN BẠN VIẾT ----------

// 1. Trả về tổng tiền (kiểu number) = soLuong × donGia + VAT + phiGiao.
function tinhTong(soLuong, donGia, phiGiao) {
	// TODO
}

// 2. Trả về chuỗi mô tả số lần in lại.
function moTaInLai(soLan) {
	// TODO
}

// 3. Trả về chuỗi phiếu xác nhận gồm đúng 5 dòng.
function inPhieu(don) {
	// TODO
}

// 4. Trả về một đơn MỚI để in lại; đơn cũ không được thay đổi.
function taoDonInLai(donCu, sdtMoi) {
	// TODO
}

// ---------- CHẠY THỬ (không sửa) ----------
const donInLai = taoDonInLai(donGoc, "0988888888");
hienThi(inPhieu(donGoc));
hienThi("");
hienThi(inPhieu(donInLai));
console.table([donGoc, donInLai]);
